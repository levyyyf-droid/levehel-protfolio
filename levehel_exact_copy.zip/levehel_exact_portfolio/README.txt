LEVEHEL PORTFOLIO — ORIGINAL DESIGN + FUNCTIONAL PHP

This version preserves the original portfolio's page structure, navigation, student card, About section, skills, project cards, contact form, footer, and messages inbox. It updates the displayed name to Levehel and changes the theme to pale pink and watery blue.

FILES
- index.php: main portfolio and validated contact form
- messages.php: inbox that displays submitted messages
- style.css: loads the original stylesheet and applies Levehel's color theme

RUNNING IT
This is a PHP + MySQL website, not a static GitHub Pages site. To run it, use a PHP/MySQL server such as XAMPP: put this folder inside htdocs, start Apache and MySQL, then visit http://localhost/levehel_exact_portfolio/ . The PHP creates the levehel_portfolio database and messages table automatically using the local MySQL root account with an empty password, matching the original project's setup. If your local MySQL account uses a password, edit the database settings at the top of both PHP files.

IMPORTANT
The contact form stores submissions in the local database. The messages.php inbox is intended for local development/testing; do not publish a public inbox containing visitors' private messages. Replace contact details only with details you are comfortable sharing.

The stylesheet imports the original public GitHub CSS file, so internet access is needed for that stylesheet as well as the Google Fonts and Bootstrap resources already used by the original page.
